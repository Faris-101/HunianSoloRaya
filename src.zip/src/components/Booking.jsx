import { useState } from "react";
import { CONTACT_INFO } from "../data/index";
import { getIcon } from "../utils/iconMap";

const INIT = { nama:"", hp:"", email:"", proyek:"", unit:"", pesan:"" };

export default function Booking({ onSubmit }) {
  const [form, setForm] = useState(INIT);
  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const inputCls = "w-full px-4 py-[0.9rem] bg-white/5 border border-white/10 font-sans text-[0.88rem] text-white outline-none transition-colors duration-200 focus:border-gold resize-none";
  const labelCls = "block text-[0.7rem] tracking-[0.12em] uppercase text-white/35 mb-2";

  return (
    <section id="booking" className="px-16 py-24 bg-dark text-white max-lg:px-8 max-md:px-5 max-md:py-12">
      <div className="grid grid-cols-[1fr_1.5fr] gap-20 max-lg:grid-cols-1 max-lg:gap-12">

        {/* Info */}
        <div>
          <div className="flex items-center gap-3 text-[0.72rem] tracking-[0.22em] uppercase text-gold mb-4 before:content-[''] before:block before:w-8 before:h-px before:bg-gold">
            Hubungi Kami
          </div>
          <h2 className="font-serif text-[clamp(2rem,3.5vw,3rem)] font-light leading-[1.2] mb-4">
            Jadwalkan<br /><em className="italic text-gold">Kunjungan</em> Anda
          </h2>
          <p className="text-white/45 text-[0.92rem] leading-[1.7] max-w-[360px] mb-12">
            Tim marketing kami siap membantu Anda menemukan properti yang tepat. Isi formulir dan kami akan menghubungi Anda dalam 24 jam.
          </p>

          <div className="mt-12 flex flex-col">
            {CONTACT_INFO.map(({ icon, label, value }) => (
              <div key={label} className="flex items-center gap-4 py-5 border-b border-white/8">
                <div className="w-10 h-10 bg-gold/15 flex items-center justify-center text-gold text-base flex-shrink-0">
                  {getIcon(icon)}
                </div>
                <div>
                  <strong className="block text-[0.8rem] font-medium mb-px">{label}</strong>
                  <span className="text-white/40 text-[0.78rem]">{value}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Form */}
        <div className="flex flex-col gap-4">
          <div className="grid grid-cols-2 gap-4 max-md:grid-cols-1">
            <div>
              <label className={labelCls}>Nama Lengkap</label>
              <input className={inputCls} type="text" placeholder="Fulan" value={form.nama} onChange={e => set("nama", e.target.value)} />
            </div>
            <div>
              <label className={labelCls}>Nomor HP / WA</label>
              <input className={inputCls} type="tel" placeholder="+62 812 xxxx xxxx" value={form.hp} onChange={e => set("hp", e.target.value)} />
            </div>
          </div>

          <div>
            <label className={labelCls}>Email</label>
            <input className={inputCls} type="email" placeholder="email@anda.com" value={form.email} onChange={e => set("email", e.target.value)} />
          </div>

          <div className="grid grid-cols-2 gap-4 max-md:grid-cols-1">
            <div>
              <label className={labelCls}>Proyek yang Diminati</label>
              <select className={inputCls + " appearance-none"} value={form.proyek} onChange={e => set("proyek", e.target.value)}>
                <option value="" className="bg-dark">Pilih proyek...</option>
                {["Cluster Gedongan 8","Cluster Gedongan 7","Amarta Residence 3","Amarta Residence 4","Graha Presidency","Graha Adisutjipto","Solo Townhouse 6","Taman Ayodya 2"].map(o => (
                  <option key={o} className="bg-dark">{o}</option>
                ))}
              </select>
            </div>
            <div>
              <label className={labelCls}>Tipe Unit</label>
              <select className={inputCls + " appearance-none"} value={form.unit} onChange={e => set("unit", e.target.value)}>
                <option value="" className="bg-dark">Pilih tipe unit...</option>
                {["1 Lantai","Mezanin","2 Lantai"].map(o => <option key={o} className="bg-dark">{o}</option>)}
              </select>
            </div>
          </div>

          <div>
            <label className={labelCls}>Pesan / Pertanyaan</label>
            <textarea className={inputCls} rows={4} placeholder="Tuliskan pertanyaan atau kebutuhan Anda..." value={form.pesan} onChange={e => set("pesan", e.target.value)} />
          </div>

          <button
            onClick={() => { onSubmit(); setForm(INIT); }}
            className="mt-2 px-8 py-4 bg-gold text-dark font-sans text-[0.8rem] tracking-[0.12em] uppercase font-medium cursor-pointer hover:opacity-85 transition-opacity duration-200 border-0"
          >
            Kirim &amp; Jadwalkan Kunjungan →
          </button>

          <p className="text-[0.72rem] text-white/25 leading-[1.6]">
            Dengan mengirimkan form ini, Anda menyetujui untuk dihubungi oleh tim kami. Data Anda aman dan tidak akan dibagikan ke pihak ketiga.
          </p>
        </div>
      </div>
    </section>
  );
}
