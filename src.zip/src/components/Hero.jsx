export default function Hero() {
  return (
    <section id="home" className="min-h-screen grid grid-cols-2 pt-20 overflow-hidden max-lg:grid-cols-1 max-lg:min-h-auto">
      {/* Kiri */}
      <div className="flex flex-col justify-center px-16 py-20 max-lg:px-8 max-lg:pt-24 max-lg:pb-12 max-md:px-5 max-md:pt-20">
        <div className="flex items-center gap-3 text-[0.75rem] tracking-[0.2em] uppercase text-gold mb-6 before:content-[''] before:block before:w-8 before:h-px before:bg-gold animate-fade-up [animation-delay:0.1s]">
          Developer Properti Terpercaya
        </div>

        <h1 className="font-serif text-[clamp(3rem,5vw,5rem)] font-light leading-[1.08] mb-6 tracking-[-0.01em] animate-fade-up [animation-delay:0.2s]">
          Hunian <em className="italic text-gold">Premium</em>
          <br />untuk Gaya Hidup Modern
        </h1>

        <p className="text-[0.95rem] leading-[1.75] text-gray max-w-[420px] mb-12 animate-fade-up [animation-delay:0.3s]">
          Lebih dari 5 kawasan perumahan eksklusif tersebar di lokasi strategis.
          Kami menghadirkan hunian berkualitas tinggi dengan desain kontemporer dan fasilitas lengkap.
        </p>

        <div className="flex gap-4 items-center animate-fade-up [animation-delay:0.4s] max-md:flex-col max-md:items-start">
          <a href="#proyek" className="btn-primary">Lihat Proyek</a>
          <a href="#simulasi" className="btn-secondary">Simulasi Pembayaran</a>
        </div>
      </div>

      {/* Kanan */}
      <div className="relative bg-dark overflow-hidden max-lg:h-[50vh] max-md:h-[40vh]">
        <div className="grid grid-rows-2 h-full gap-px">
          <div className="relative overflow-hidden">
            <img src="/assets/foto-3.PNG" alt="Rumah Premium" className="w-full h-full object-cover" />
            <div className="absolute bottom-8 right-8 bg-gold text-dark px-6 py-4 text-[0.75rem] tracking-[0.1em] uppercase font-medium">
              Avalia Residence
            </div>
          </div>
          <div className="relative overflow-hidden">
            <img src="/assets/foto-1.PNG" alt="Rumah Premium" className="w-full h-full object-cover" />
          </div>
        </div>
      </div>
    </section>
  );
}
